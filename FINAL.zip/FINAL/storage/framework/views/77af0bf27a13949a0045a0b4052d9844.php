<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\USER\Desktop\SCOW\FINAL\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>